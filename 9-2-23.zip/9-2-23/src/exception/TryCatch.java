package exception;

public class TryCatch {

	public static void main(String args[]) {
		method1();
		System.out.println("main Ended");
	}
	private static void method1() {
		method2();
		System.out.println("method1 Ended");
		
	}
	private static void method2() {
		try {
		String str =null;
		str.length();
		System.out.println("method2 Ended");
		}catch(Exception ex) {
		
	}
}
}