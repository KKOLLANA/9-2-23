package exception;

public class Demo {
	public static void main(String[] args) {
 String st = "Kiran";
 String st1 = "kiran";
 String str2 = "alekya";
 	
 System.out.println(st+  ""  +str2);
 System.out.println(st.equals(str2));
 System.out.println(st.equals(st1));
 
 
}
}