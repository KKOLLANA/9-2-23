package cg.Static;

public class StaticVar {
	static int num = 15;
	
	public static void main (String[] args) {
		System.out.println(StaticVar.num);
		
	}

}
