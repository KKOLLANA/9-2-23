package cg.Static;

public class StaticMethods {
	static void home(){
		System.out.println("hellokiran");
	}
	static void pig() {
		System.out.println("hello pig");
	
	}
	public void hello() {
		System.out.println("Alekhya");
	}		
	public static void main(String args[]) {
		System.out.println("hello manoj");
		
		StaticMethods.home();
		StaticMethods s1 = new StaticMethods();
		s1.hello();
	}
	static {
		System.out.println("hello alk");
		StaticMethods.pig();
		StaticMethods.home();
			}
}
