package cg.Static;

public class StaticBlock {
	
	public static void main(String args[]) {
		System.out.println("hello manoj");
	}
	static {
		System.out.println("hi kiran");
	}
	static {
		System.out.println("deman");
	}
	
	
	}


