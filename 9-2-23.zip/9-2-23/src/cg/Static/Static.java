package cg.Static;

public class Static {
	static String collagneame = "k.v.sangatan";
	int StudentRillNO;
	String StudentName ;
	
public Static(int studentRillNO, String studentName) {
		
		StudentRillNO = studentRillNO;
		StudentName = studentName;
	}
	void display()
	{
		System.out.println(collagneame + "  " + StudentRillNO + "  " + StudentName);
	}
public static void main(String[] args){
	Static s1 = new Static(221, "manoj");
	Static s2 = new Static(2212, "samanth");
	Static s3 = new Static(225, "kiran");
	Static s4 = new Static(261, "mounaka");
	s1.display();
	s2.display();
	s3.display();
	s4.display();
}
}
